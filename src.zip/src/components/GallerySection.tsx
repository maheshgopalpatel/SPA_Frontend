// import { useState } from 'react';
// import { Card } from '@/components/ui/card';
// import { Button } from '@/components/ui/button';
// import { Maximize2 } from 'lucide-react';
// import { Dialog, DialogContent } from '@/components/ui/dialog';
// import g1 from "../assets/g1.png";
// import g2 from "../assets/g2.png";
// import g3 from "../assets/gg3.png";
// import g4 from "../assets/g4.png";

// const GallerySection = () => {
//   const [selectedItem, setSelectedItem] = useState<string | null>(null);
//   const [currentCategory, setCurrentCategory] = useState('Interior');

//   const categories = ['All', 'Interior', 'Treatments', 'Staff', 'Products'];

//   const galleryItems = [
//     { id: 1, url: g1, category: 'Interior', title: 'Reception Area', description: 'Welcoming and elegant reception space' },
//     { id: 2, url: "/abg.mp4", category: 'Interior', title: 'Location Detail', description: 'Welcoming and elegant location space' },
//     { id: 3, url: 'https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?w=500&h=400&fit=crop', category: 'Treatments', title: 'Facial Treatment Room', description: 'Private and serene treatment environment' },
//     { id: 4, url: 'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=500&h=400&fit=crop', category: 'Treatments', title: 'Massage Therapy', description: 'Relaxing massage therapy sessions' },
//     { id: 5, url: 'https://images.unsplash.com/photo-1522336572468-97b06e8ef143?w=500&h=400&fit=crop', category: 'Treatments', title: 'Hair Styling', description: 'Professional hair styling services' },
//     { id: 6, url: g2, category: 'Interior', title: 'Office Area', description: 'A spacious and organized office area designed for productivity.' },
//     { id: 7, url: 'https://images.unsplash.com/photo-1604654894610-df63bc536371?w=500&h=400&fit=crop', category: 'Treatments', title: 'Nail Care', description: 'Professional manicure and pedicure services' },
//     { id: 8, url: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=500&h=400&fit=crop', category: 'Treatments', title: 'Bridal Services', description: 'Complete bridal makeover packages' },
//     { id: 9, url: 'https://images.unsplash.com/photo-1515377905703-c4788e51af15?w=500&h=400&fit=crop', category: 'Products', title: 'Premium Products', description: 'High-quality beauty and wellness products' },
//     { id: 10, url: g3, category: 'Interior', title: 'Staff Working Room', description: 'A comfortable and well-equipped space for staff to work efficiently.' },
//     { id: 11, url: g4, category: 'Interior', title: 'Relaxation Lounge', description: 'Comfortable waiting and relaxation area' },
//   ];

//   const filteredItems = currentCategory === 'All'
//     ? galleryItems
//     : galleryItems.filter(item => item.category === currentCategory);

//   return (
//     <section id="gallery" className="py-10 md:py-20 bg-background">
//       <div className="container mx-auto px-4">
//         {/* Header */}
//         <div className="text-center mb-16 animate-fade-in">
//           <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Our Gallery</h2>
//           <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
//             Take a virtual tour of our beautiful spa and see our expert team in action
//           </p>
//         </div>

//         {/* Category Filter */}
//         <div className="flex flex-wrap justify-center gap-3 mb-12 animate-scale-in">
//           {categories.map(category => (
//             <Button
//               key={category}
//               variant={currentCategory === category ? "default" : "outline"}
//               onClick={() => setCurrentCategory(category)}
//               className="transition-all duration-300 hover:scale-105"
//             >
//               {category}
//             </Button>
//           ))}
//         </div>

//         {/* Gallery Grid */}
//         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
//           {filteredItems.map((item, index) => (
//             <Card
//               key={item.id}
//               className="group overflow-hidden bg-gradient-card border-0 shadow-soft hover:shadow-strong transition-all duration-500 hover:-translate-y-2 animate-slide-up cursor-pointer"
//               style={{ animationDelay: `${index * 0.1}s` }}
//               onClick={() => setSelectedItem(item.url)}
//             >
//               <div className="relative overflow-hidden">
//                 {item.url.endsWith('.mp4') ? (
//                   <video
//                     src={item.url}
//                     autoPlay
//                     loop
//                     muted
//                     playsInline
//                     className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
//                   />
//                 ) : (
//                   <img
//                     src={item.url}
//                     alt={item.title}
//                     className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
//                   />
//                 )}

//                 <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

//                 <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
//                   <Button
//                     size="sm"
//                     variant="secondary"
//                     className="bg-white/20 border-white/30 text-white hover:bg-white/30 backdrop-blur-sm"
//                   >
//                     <Maximize2 className="w-4 h-4 mr-2" />
//                     View
//                   </Button>
//                 </div>

//                 <div className="absolute bottom-0 left-0 right-0 p-4 text-white transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
//                   <h3 className="font-semibold text-lg mb-1">{item.title}</h3>
//                   <p className="text-sm text-white/90">{item.description}</p>
//                 </div>
//               </div>
//             </Card>
//           ))}
//         </div>

//         {/* Modal */}
//         <Dialog open={!!selectedItem} onOpenChange={() => setSelectedItem(null)}>
//           <DialogContent className="max-w-4xl bg-black/95 border-0 p-0">
//             {selectedItem && (
//               <div className="relative">
//                 {selectedItem.endsWith('.mp4') ? (
//                   <video
//                     src={selectedItem}
//                     controls
//                     autoPlay
//                     loop
//                     muted
//                     playsInline
//                     className="w-full h-auto max-h-[80vh] object-contain"
//                   />
//                 ) : (
//                   <img
//                     src={selectedItem}
//                     alt="Gallery Item"
//                     className="w-full h-auto max-h-[80vh] object-contain"
//                   />
//                 )}

//                 <Button
//                   variant="ghost"
//                   size="icon"
//                   className="absolute top-4 right-4 text-white hover:bg-white/20"
//                   onClick={() => setSelectedItem(null)}
//                 >
//                   ×
//                 </Button>
//               </div>
//             )}
//           </DialogContent>
//         </Dialog>

//         {/* CTA */}
//         <div className="text-center mt-16 animate-fade-in">
//           <div className="max-w-lg mx-auto">
//             <h3 className="text-2xl font-bold text-foreground mb-4">Experience It Yourself</h3>
//             <p className="text-muted-foreground mb-6">
//               Book your appointment today and discover why we're the city's favorite spa
//             </p>
//             <Button
//               size="lg"
//               className="bg-amber-600 hover:opacity-90 transition-all duration-300 hover:scale-105"
//               onClick={() => {
//                 const element = document.querySelector('#services');
//                 if (element) element.scrollIntoView({ behavior: 'smooth' });
//               }}
//             >
//               Book Your Visit
//             </Button>
//           </div>
//         </div>
//       </div>
//     </section>
//   );
// };

// export default GallerySection;



// import { useState } from "react";
// import { motion } from "framer-motion";
// import { Card } from "@/components/ui/card";
// import { Button } from "@/components/ui/button";
// import { Maximize2 } from "lucide-react";
// import { Dialog, DialogContent } from "@/components/ui/dialog";
// import g1 from "../assets/g1.png";
// import g2 from "../assets/g2.png";
// import g3 from "../assets/gg3.png";
// import g4 from "../assets/g4.png";

// // Animation variants
// const fadeUp = {
//   hidden: { opacity: 0, y: 40 },
//   visible: { opacity: 1, y: 0 },
// };

// const scaleUp = {
//   hidden: { opacity: 0, scale: 0.9, y: 40 },
//   visible: { opacity: 1, scale: 1, y: 0 },
// };

// const GallerySection: React.FC = () => {
//   const [selectedItem, setSelectedItem] = useState<string | null>(null);
//   const [currentCategory, setCurrentCategory] = useState("Interior");

//   const categories = ["All", "Interior", "Treatments", "Staff", "Products"];

//   const galleryItems = [
//     { id: 1, url: g1, category: "Interior", title: "Reception Area", description: "Welcoming and elegant reception space" },
//     { id: 2, url: "/abg.mp4", category: "Interior", title: "Location Detail", description: "Welcoming and elegant location space" },
//     { id: 3, url: "https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?w=500&h=400&fit=crop", category: "Treatments", title: "Facial Treatment Room", description: "Private and serene treatment environment" },
//     { id: 4, url: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=500&h=400&fit=crop", category: "Treatments", title: "Massage Therapy", description: "Relaxing massage therapy sessions" },
//     { id: 5, url: "https://images.unsplash.com/photo-1522336572468-97b06e8ef143?w=500&h=400&fit=crop", category: "Treatments", title: "Hair Styling", description: "Professional hair styling services" },
//     { id: 6, url: g2, category: "Interior", title: "Office Area", description: "A spacious and organized office area designed for productivity." },
//     { id: 7, url: "https://images.unsplash.com/photo-1604654894610-df63bc536371?w=500&h=400&fit=crop", category: "Treatments", title: "Nail Care", description: "Professional manicure and pedicure services" },
//     { id: 8, url: "https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=500&h=400&fit=crop", category: "Treatments", title: "Bridal Services", description: "Complete bridal makeover packages" },
//     { id: 9, url: "https://images.unsplash.com/photo-1515377905703-c4788e51af15?w=500&h=400&fit=crop", category: "Products", title: "Premium Products", description: "High-quality beauty and wellness products" },
//     { id: 10, url: g3, category: "Interior", title: "Staff Working Room", description: "A comfortable and well-equipped space for staff to work efficiently." },
//     { id: 11, url: g4, category: "Interior", title: "Relaxation Lounge", description: "Comfortable waiting and relaxation area" },
//   ];

//   const filteredItems = currentCategory === "All"
//     ? galleryItems
//     : galleryItems.filter(item => item.category === currentCategory);

//   return (
//     <section id="gallery" className="py-10 md:py-20 bg-background">
//       <div className="container mx-auto px-4">

//         {/* Header */}
//         <motion.div
//           className="text-center mb-16"
//           initial="hidden"
//           whileInView="visible"
//           viewport={{ once: true }}
//           variants={fadeUp}
//           transition={{ duration: 0.5 }}
//         >
//           <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Our Gallery</h2>
//           <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
//             Take a virtual tour of our beautiful spa and see our expert team in action
//           </p>
//         </motion.div>

//         {/* Category Filter */}
//         <motion.div
//           className="flex flex-wrap justify-center gap-3 mb-12"
//           initial="hidden"
//           whileInView="visible"
//           viewport={{ once: true }}
//           variants={fadeUp}
//           transition={{ duration: 0.5 }}
//         >
//           {categories.map(category => (
//             <Button
//               key={category}
//               variant={currentCategory === category ? "default" : "outline"}
//               onClick={() => setCurrentCategory(category)}
//               className="transition-all duration-300 hover:scale-105"
//             >
//               {category}
//             </Button>
//           ))}
//         </motion.div>

//         {/* Gallery Grid */}
//         {/* <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
//           {filteredItems.map((item, index) => (
//             <motion.div
//               key={item.id}
//               variants={scaleUp}
//               initial="hidden"
//               whileInView="visible"
//               viewport={{ once: false }}
//               transition={{ delay: index * 0.1, duration: 0.6 }}
//             >
//               <Card
//                 className="group overflow-hidden bg-gradient-card border-0 shadow-soft hover:shadow-strong transition-all duration-500 hover:-translate-y-2 cursor-pointer"
//                 onClick={() => setSelectedItem(item.url)}
//               >
//                 <div className="relative overflow-hidden">
//                   {item.url.endsWith(".mp4") ? (
//                     <video
//                       src={item.url}
//                       autoPlay
//                       loop
//                       muted
//                       playsInline
//                       className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
//                     />
//                   ) : (
//                     <img
//                       src={item.url}
//                       alt={item.title}
//                       className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
//                     />
//                   )}

//                   <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

//                   <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
//                     <Button
//                       size="sm"
//                       variant="secondary"
//                       className="bg-white/20 border-white/30 text-white hover:bg-white/30 backdrop-blur-sm"
//                     >
//                       <Maximize2 className="w-4 h-4 mr-2" />
//                       View
//                     </Button>
//                   </div>

//                   <div className="absolute bottom-0 left-0 right-0 p-4 text-white transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
//                     <h3 className="font-semibold text-lg mb-1">{item.title}</h3>
//                     <p className="text-sm text-white/90">{item.description}</p>
//                   </div>
//                 </div>
//               </Card>
//             </motion.div>
//           ))}
//         </div> */}

//         {/* Gallery Grid */}
// <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-6">
//   {filteredItems.map((item, index) => (
//     <motion.div
//       key={item.id}
//       variants={scaleUp}
//       initial="hidden"
//       whileInView="visible"
//       viewport={{ once: false }}
//       transition={{ delay: index * 0.1, duration: 0.6 }}
//     >
//       <Card
//         className="group overflow-hidden bg-gradient-card border-0 shadow-soft hover:shadow-strong transition-all duration-500 hover:-translate-y-2 cursor-pointer"
//         onClick={() => setSelectedItem(item.url)}
//       >
//         <div className="relative overflow-hidden">
//           {item.url.endsWith(".mp4") ? (
//             <video
//               src={item.url}
//               autoPlay
//               loop
//               muted
//               playsInline
//               className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
//             />
//           ) : (
//             <img
//               src={item.url}
//               alt={item.title}
//               className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
//             />
//           )}

//           <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

//           <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
//             <Button
//               size="sm"
//               variant="secondary"
//               className="bg-white/20 border-white/30 text-white hover:bg-white/30 backdrop-blur-sm"
//             >
//               <Maximize2 className="w-4 h-4 mr-2" />
//               View
//             </Button>
//           </div>

//           <div className="absolute bottom-0 left-0 right-0 p-4 text-white transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
//             <h3 className="font-semibold text-lg mb-1">{item.title}</h3>
//             <p className="text-sm text-white/90">{item.description}</p>
//           </div>
//         </div>
//       </Card>
//     </motion.div>
//   ))}
// </div>


//         {/* Modal */}
//         <Dialog open={!!selectedItem} onOpenChange={() => setSelectedItem(null)}>
//           <DialogContent className="max-w-4xl bg-black/95 border-0 p-0">
//             {selectedItem && (
//               <div className="relative">
//                 {selectedItem.endsWith(".mp4") ? (
//                   <video
//                     src={selectedItem}
//                     controls
//                     autoPlay
//                     loop
//                     muted
//                     playsInline
//                     className="w-full h-auto max-h-[80vh] object-contain"
//                   />
//                 ) : (
//                   <img
//                     src={selectedItem}
//                     alt="Gallery Item"
//                     className="w-full h-auto max-h-[80vh] object-contain"
//                   />
//                 )}

//                 <Button
//                   variant="ghost"
//                   size="icon"
//                   className="absolute top-4 right-4 text-white hover:bg-white/20"
//                   onClick={() => setSelectedItem(null)}
//                 >
//                   ×
//                 </Button>
//               </div>
//             )}
//           </DialogContent>
//         </Dialog>

//       </div>
//     </section>
//   );
// };

// export default GallerySection;




import { useState } from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Maximize2 } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import g1 from "../assets/g1.png";
import g2 from "../assets/g2.png";
import g3 from "../assets/gg3.png";
import g4 from "../assets/g4.png";

// Animation variants
const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0 },
};

const scaleUp = {
  hidden: { opacity: 0, scale: 0.95, y: 20 },
  visible: { opacity: 1, scale: 1, y: 0 },
};

const GallerySection: React.FC = () => {
  const [selectedItem, setSelectedItem] = useState<string | null>(null);
  const [currentCategory, setCurrentCategory] = useState("Interior");

  const categories = ["All", "Interior", "Treatments", "Staff", "Products"];

  const galleryItems = [
    { id: 1, url: g1, category: "Interior", title: "Reception Area", description: "Welcoming and elegant reception space" },
    { id: 2, url: "/abg.mp4", category: "Interior", title: "Location Detail", description: "Welcoming and elegant location space" },
    { id: 3, url: "https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?w=500&h=400&fit=crop", category: "Treatments", title: "Facial Treatment Room", description: "Private and serene treatment environment" },
    { id: 4, url: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=500&h=400&fit=crop", category: "Treatments", title: "Massage Therapy", description: "Relaxing massage therapy sessions" },
    { id: 5, url: "https://images.unsplash.com/photo-1522336572468-97b06e8ef143?w=500&h=400&fit=crop", category: "Treatments", title: "Hair Styling", description: "Professional hair styling services" },
    { id: 6, url: g2, category: "Interior", title: "Office Area", description: "A spacious and organized office area designed for productivity." },
    { id: 7, url: "https://images.unsplash.com/photo-1604654894610-df63bc536371?w=500&h=400&fit=crop", category: "Treatments", title: "Nail Care", description: "Professional manicure and pedicure services" },
    { id: 8, url: "https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=500&h=400&fit=crop", category: "Treatments", title: "Bridal Services", description: "Complete bridal makeover packages" },
    { id: 9, url: "https://images.unsplash.com/photo-1515377905703-c4788e51af15?w=500&h=400&fit=crop", category: "Products", title: "Premium Products", description: "High-quality beauty and wellness products" },
    { id: 10, url: g3, category: "Interior", title: "Staff Working Room", description: "A comfortable and well-equipped space for staff to work efficiently." },
    { id: 11, url: g4, category: "Interior", title: "Relaxation Lounge", description: "Comfortable waiting and relaxation area" },
  ];

  const filteredItems = currentCategory === "All"
    ? galleryItems
    : galleryItems.filter(item => item.category === currentCategory);

  return (
    <section id="gallery" className="py-8 sm:py-12 md:py-16 bg-background">
      <div className="container mx-auto px-4">

        {/* Header */}
        <motion.div
          className="text-center mb-12 sm:mb-16"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUp}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-foreground mb-2 sm:mb-3">Our Gallery</h2>
          <p className="text-sm sm:text-base md:text-lg text-muted-foreground max-w-2xl mx-auto">
            Take a virtual tour of our beautiful spa and see our expert team in action
          </p>
        </motion.div>

        {/* Category Filter */}
        <motion.div
          className="flex flex-wrap justify-center gap-2 sm:gap-3 mb-8 sm:mb-12"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUp}
          transition={{ duration: 0.5 }}
        >
          {categories.map(category => (
            <Button
              key={category}
              variant={currentCategory === category ? "default" : "outline"}
              onClick={() => setCurrentCategory(category)}
              className="transition-all duration-300 text-xs sm:text-sm md:text-base px-3 sm:px-4"
            >
              {category}
            </Button>
          ))}
        </motion.div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-3 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
          {filteredItems.map((item, index) => (
            <motion.div
              key={item.id}
              variants={scaleUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: false }}
              transition={{ delay: index * 0.05, duration: 0.5 }}
            >
              <Card
                className="group overflow-hidden bg-gradient-card border-0 shadow-soft hover:shadow-strong transition-all duration-500 hover:-translate-y-1 cursor-pointer"
                onClick={() => setSelectedItem(item.url)}
              >
                <div className="relative overflow-hidden">
                  {item.url.endsWith(".mp4") ? (
                    <video
                      src={item.url}
                      autoPlay
                      loop
                      muted
                      playsInline
                      className="w-full h-40 sm:h-48 md:h-52 object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  ) : (
                    <img
                      src={item.url}
                      alt={item.title}
                      className="w-full h-40 sm:h-48 md:h-52 object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  )}

                  {/* Overlay */}
                  <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <Button
                      size="sm"
                      variant="secondary"
                      className="bg-white/20 border-white/30 text-white hover:bg-white/30 backdrop-blur-sm"
                    >
                      <Maximize2 className="w-4 h-4 mr-1 sm:mr-2" />
                      View
                    </Button>
                  </div>

                  {/* Caption */}
                  <div className="absolute bottom-0 left-0 right-0 p-2 sm:p-3 text-white transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                    <h3 className="font-semibold text-sm sm:text-base">{item.title}</h3>
                    <p className="text-[10px] sm:text-sm text-white/90">{item.description}</p>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Modal */}
        <Dialog open={!!selectedItem} onOpenChange={() => setSelectedItem(null)}>
          <DialogContent className="max-w-4xl bg-black/95 border-0 p-0">
            {selectedItem && (
              <div className="relative">
                {selectedItem.endsWith(".mp4") ? (
                  <video
                    src={selectedItem}
                    controls
                    autoPlay
                    loop
                    muted
                    playsInline
                    className="w-full h-auto max-h-[80vh] object-contain"
                  />
                ) : (
                  <img
                    src={selectedItem}
                    alt="Gallery Item"
                    className="w-full h-auto max-h-[80vh] object-contain"
                  />
                )}

                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-4 right-4 text-white hover:bg-white/20"
                  onClick={() => setSelectedItem(null)}
                >
                  ×
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>

      </div>
    </section>
  );
};

export default GallerySection;

