// import { useState } from "react";
// import { Card, CardContent } from "@/components/ui/card";
// import { Button } from "@/components/ui/button";
// import { Badge } from "@/components/ui/badge";
// import { Scissors, Sparkles, Palette, Crown, Heart, Hand } from "lucide-react";
// import BookingPopup, { Service } from "./BookingPopup";
// import m1 from "../assets/thai.jpg"
// import m2 from "../assets/sublime.jpg"
// import m3 from "../assets/Hot-Stone.jpg"
// import m4 from "../assets/abhiyanga.jpg"
// import m5 from "../assets/welness.jpg"
// import m6 from "../assets/balinese.jpg"
// import m7 from "../assets/sleep.jpg"
// import m8 from "../assets/deep.jpg"
// import m9 from "../assets/sport.jpg"
// import m10 from "../assets/potli.jpg"
// import m11 from "../assets/head.jpg"
// import m12 from "../assets/foot.jpg"

// const ServicesSection: React.FC = () => {
//   const [selectedCategory, setSelectedCategory] = useState("Massage");
//   const [selectedService, setSelectedService] = useState<Service | null>(null);
//   const [showPopup, setShowPopup] = useState(false);

//   const categories = [
//     { name: "All", icon: Crown },
//     { name: "Hair", icon: Scissors },
//     { name: "Skin", icon: Sparkles },
//     { name: "Massage", icon: Hand },
//     { name: "Beauty", icon: Palette },
//     { name: "Special", icon: Heart },
//   ];

//   // Existing services
//   const existingServices: Service[] = [
//     {
//       id: 1,
//       name: "Hair Cut & Styling",
//       category: "Hair",
//       price: "₹800",
//       duration: "45 min",
//       image:
//         "https://images.unsplash.com/photo-1560066984-138dadb4c035?w=300&h=200&fit=crop",
//       description: "Professional hair cutting and styling for all hair types",
//       popular: true,
//     },
//     {
//       id: 2,
//       name: "Facial Treatment",
//       category: "Skin",
//       price: "₹1,200",
//       duration: "60 min",
//       image:
//         "https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?w=300&h=200&fit=crop",
//       description: "Deep cleansing facial with premium skincare products",
//       popular: false,
//     },
//     {
//       id: 3,
//       name: "Full Body Massage",
//       category: "Massage",
//       price: "₹2,000",
//       duration: "90 min",
//       image:
//         "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=300&h=200&fit=crop",
//       description: "Relaxing full body massage with aromatic oils",
//       popular: true,
//     },
//     {
//       id: 4,
//       name: "Hair Coloring",
//       category: "Hair",
//       price: "₹1,500",
//       duration: "120 min",
//       image:
//         "https://images.unsplash.com/photo-1522336572468-97b06e8ef143?w=300&h=200&fit=crop",
//       description: "Professional hair coloring with premium products",
//       popular: false,
//     },
//     {
//       id: 5,
//       name: "Manicure & Pedicure",
//       category: "Beauty",
//       price: "₹900",
//       duration: "75 min",
//       image:
//         "https://images.unsplash.com/photo-1604654894610-df63bc536371?w=300&h=200&fit=crop",
//       description: "Complete nail care and beautification",
//       popular: false,
//     },
//     {
//       id: 6,
//       name: "Bridal Package",
//       category: "Special",
//       price: "₹8,000",
//       duration: "4 hours",
//       image:
//         "https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=300&h=200&fit=crop",
//       description: "Complete bridal makeover package",
//       popular: true,
//     },
//   ];

//   // Massage services
//   const massageServices: Service[] = [
//     {
//       id: 101,
//       name: "Thai Massage",
//       category: "Massage",
//       description:
//         "Traditional Thai massage to relax muscles and improve energy flow",
//       image: m1,
//       popular: true,
//       options: [
//         { duration: "45 min", price: "₹1200" },
//         { duration: "60 min", price: "₹1500" },
//         { duration: "90 min", price: "₹2000" },
//       ],
//     },
//     {
//       id: 102,
//       name: "Sublime Swedish Therapy",
//       category: "Massage",
//       description: "Gentle Swedish massage for relaxation and circulation",
//       image:
//         m2,
//       popular: false,
//       options: [
//         { duration: "45 min", price: "₹1300" },
//         { duration: "60 min", price: "₹1600" },
//         { duration: "90 min", price: "₹2000" },
//       ],
//     },
//     {
//       id: 103,
//       name: "Hot Stone Therapy",
//       category: "Massage",
//       description: "Therapeutic massage with heated stones to relieve tension",
//       image:
//         m3,
//       popular: true,
//       options: [
//         { duration: "45 min", price: "₹1500" },
//         { duration: "60 min", price: "₹2000" },
//         { duration: "90 min", price: "₹3000" },
//       ],
//     },
//     {
//       id: 104,
//       name: "Abhyanga Therapy",
//       category: "Massage",
//       description: "Traditional Indian oil massage for complete relaxation",
//       image:
//         m4,
//       popular: false,
//       options: [
//         { duration: "45 min", price: "₹1500" },
//         { duration: "60 min", price: "₹2000" },
//         { duration: "90 min", price: "₹3000" },
//       ],
//     },
//     {
//       id: 105,
//       name: "Wellness Retreat Therapy",
//       category: "Massage",
//       description: "Extended wellness therapy for mind and body",
//       image:
//         m5,
//       popular: false,
//       options: [{ duration: "90 min", price: "₹3000" }],
//     },
//     {
//       id: 106,
//       name: "Balinese Therapy",
//       category: "Massage",
//       description: "Exotic Balinese massage for deep relaxation",
//       image:
//         m6,
//       popular: false,
//       options: [
//         { duration: "45 min", price: "₹1500" },
//         { duration: "60 min", price: "₹2000" },
//         { duration: "90 min", price: "₹3000" },
//       ],
//     },
//     {
//       id: 107,
//       name: "Sleep Therapy",
//       category: "Massage",
//       description: "Relaxing therapy for better sleep",
//       image:
//         m7,
//       popular: false,
//       options: [
//         { duration: "45 min", price: "₹1350" },
//         { duration: "60 min", price: "₹1700" },
//         { duration: "90 min", price: "₹2100" },
//       ],
//     },
//     {
//       id: 108,
//       name: "Deep Tissue Healing Therapy",
//       category: "Massage",
//       description: "Deep tissue massage for muscle tension relief",
//       image:
//         m8,
//       popular: false,
//       options: [
//         { duration: "45 min", price: "₹1200" },
//         { duration: "60 min", price: "₹1800" },
//         { duration: "90 min", price: "₹2100" },
//       ],
//     },
//     {
//       id: 109,
//       name: "Sports & Post Workout Therapy",
//       category: "Massage",
//       description: "Massage to recover muscles after workout",
//       image:
//         m9,
//       popular: false,
//       options: [
//         { duration: "60 min", price: "₹2100" },
//         { duration: "90 min", price: "₹3000" },
//       ],
//     },
//     {
//       id: 110,
//       name: "Healing Potli Therapy",
//       category: "Massage",
//       description: "Herbal potli therapy for relaxation",
//       image:
//         m10,
//       popular: false,
//       options: [
//         { duration: "60 min", price: "₹2500" },
//         { duration: "90 min", price: "₹3500" },
//       ],
//     },
//     {
//       id: 111,
//       name: "Head & Neck Massage",
//       category: "Massage",
//       description: "Focused massage for head, neck & shoulders",
//       image:
//         m11,
//       popular: false,
//       options: [{ duration: "20 min", price: "₹600" }],
//     },
//     {
//       id: 112,
//       name: "Foot Reflexology",
//       category: "Massage",
//       description: "Foot reflexology to relieve stress",
//       image:
//         m12,
//       popular: false,
//       options: [{ duration: "30 min", price: "₹800" }],
//     },
//   ];

//   const filteredServices =
//     selectedCategory === "All"
//       ? [...existingServices, ...massageServices]
//       : selectedCategory === "Massage"
//       ? massageServices
//       : existingServices.filter((s) => s.category === selectedCategory);

//   const handleBookNow = (service: Service) => {
//     setSelectedService(service);
//     setShowPopup(true);
//   };

//   return (
//     <section
//       id="services"
//       className="py-20 bg-gradient-to-br from-background to-spa-cream"
//     >
//       <div className="container mx-auto px-4">
//         {/* Header */}
//         <div className="text-center mb-16">
//           <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
//             Our Premium Services
//           </h2>
//           <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
//             Discover our wide range of professional treatments designed to
//             pamper and rejuvenate
//           </p>
//         </div>

//         {/* Category Filter */}
//         <div className="flex flex-wrap justify-center gap-3 mb-12">
//           {categories.map((category) => {
//             const Icon = category.icon;
//             return (
//               <Button
//                 key={category.name}
//                 variant={
//                   selectedCategory === category.name ? "default" : "outline"
//                 }
//                 onClick={() => setSelectedCategory(category.name)}
//                 className="flex items-center gap-2 transition-all duration-300 hover:scale-105"
//                 disabled = {category.name==="Massage"?false:true}
//               >
//                 <Icon className="w-4 h-4" />
//                 {category.name}
//               </Button>
//             );
//           })}
//         </div>

//         {/* Services Grid */}
//         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
//           {filteredServices.map((service, index) => (
//             <Card
//               key={service.id}
//               className="group hover:shadow-strong transition-all duration-500 hover:-translate-y-2 bg-gradient-card border-0 overflow-hidden"
//               style={{ animationDelay: `${index * 0.1}s` }}
//             >
//               <div className="relative overflow-hidden">
//                 <img
//                   src={service.image}
//                   alt={service.name}
//                   className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-110"
//                 />
//                 {service.popular && (
//                   <Badge className="absolute top-3 right-3 bg-gradient-accent text-foreground">
//                     Popular
//                   </Badge>
//                 )}
//               </div>
//               <CardContent className="p-6">
//                 <div className="flex justify-between items-start mb-3">
//                   <h3 className="text-xl font-semibold text-foreground group-hover:text-primary transition-colors">
//                     {service.name}
//                   </h3>
//                 </div>

//                 <div className="mb-4">
//                   {service.options && service.options.length > 0 ? (
//                     <div className="text-sm text-muted-foreground">
//                       {service.options.map((opt, i) => (
//                         <div key={i}>
//                           Duration: {opt.duration} | Price: {opt.price}
//                         </div>
//                       ))}
//                     </div>
//                   ) : (
//                     <span className="text-sm text-muted-foreground">
//                       Duration: {service.duration} | Price: {service.price}
//                     </span>
//                   )}
//                 </div>

//                 <div className="flex justify-between items-center">
//                   <Button
//                     onClick={() => handleBookNow(service)}
//                     size="sm"
//                     className="bg-amber-600 hover:opacity-90 transition-all duration-300 hover:scale-105"
//                   >
//                     Book Now
//                   </Button>
//                 </div>
//               </CardContent>
//             </Card>
//           ))}
//         </div>

//         {/* Popup Component */}
//         {showPopup && selectedService && (
//           <BookingPopup
//             services={[...massageServices]}
//             selectedService={selectedService}
//             onClose={() => setShowPopup(false)}
//           />
//         )}
//       </div>
//     </section>
//   );
// };

// export default ServicesSection;

// import { useState } from "react";
// import { Card, CardContent } from "@/components/ui/card";
// import { Button } from "@/components/ui/button";
// import { Badge } from "@/components/ui/badge";
// import { Scissors, Sparkles, Palette, Crown, Heart, Hand } from "lucide-react";
// import BookingPopup, { Service } from "./BookingPopup";

// import m1 from "../assets/thai.jpg";
// import m2 from "../assets/sublime.jpg";
// import m3 from "../assets/Hot-Stone.jpg";
// import m4 from "../assets/abhiyanga.jpg";
// import m5 from "../assets/welness.jpg";
// import m6 from "../assets/balinese.jpg";
// import m7 from "../assets/sleep.jpg";
// import m8 from "../assets/deep.jpg";
// import m9 from "../assets/sport.jpg";
// import m10 from "../assets/potli.jpg";
// import m11 from "../assets/head.jpg";
// import m12 from "../assets/foot.jpg";

// // 💰 Global discount percentage — change here to update everywhere
// const DISCOUNT_PERCENT = 20;

// // 🔢 Helper to calculate discounted price
// const getDiscountedPrice = (price: string) => {
//   const numeric = parseInt(price.replace(/[^\d]/g, ""), 10);
//   const discounted = numeric - (numeric * DISCOUNT_PERCENT) / 100;
//   return discounted.toFixed(0);
// };

// const ServicesSection: React.FC = () => {
//   const [selectedCategory, setSelectedCategory] = useState("Massage");
//   const [selectedService, setSelectedService] = useState<Service | null>(null);
//   const [showPopup, setShowPopup] = useState(false);

//   const categories = [
//     { name: "All", icon: Crown },
//     { name: "Hair", icon: Scissors },
//     { name: "Skin", icon: Sparkles },
//     { name: "Massage", icon: Hand },
//     { name: "Beauty", icon: Palette },
//     { name: "Special", icon: Heart },
//   ];

//   const existingServices: Service[] = [
//     {
//       id: 1,
//       name: "Hair Cut & Styling",
//       category: "Hair",
//       price: "₹800",
//       duration: "45 min",
//       image:
//         "https://images.unsplash.com/photo-1560066984-138dadb4c035?w=300&h=200&fit=crop",
//       description: "Professional hair cutting and styling for all hair types",
//       popular: true,
//     },
//     {
//       id: 2,
//       name: "Facial Treatment",
//       category: "Skin",
//       price: "₹1,200",
//       duration: "60 min",
//       image:
//         "https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?w=300&h=200&fit=crop",
//       description: "Deep cleansing facial with premium skincare products",
//       popular: false,
//     },
//     {
//       id: 3,
//       name: "Full Body Massage",
//       category: "Massage",
//       price: "₹2,000",
//       duration: "90 min",
//       image:
//         "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=300&h=200&fit=crop",
//       description: "Relaxing full body massage with aromatic oils",
//       popular: true,
//     },
//     {
//       id: 4,
//       name: "Hair Coloring",
//       category: "Hair",
//       price: "₹1,500",
//       duration: "120 min",
//       image:
//         "https://images.unsplash.com/photo-1522336572468-97b06e8ef143?w=300&h=200&fit=crop",
//       description: "Professional hair coloring with premium products",
//       popular: false,
//     },
//     {
//       id: 5,
//       name: "Manicure & Pedicure",
//       category: "Beauty",
//       price: "₹900",
//       duration: "75 min",
//       image:
//         "https://images.unsplash.com/photo-1604654894610-df63bc536371?w=300&h=200&fit=crop",
//       description: "Complete nail care and beautification",
//       popular: false,
//     },
//     {
//       id: 6,
//       name: "Bridal Package",
//       category: "Special",
//       price: "₹8,000",
//       duration: "4 hours",
//       image:
//         "https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=300&h=200&fit=crop",
//       description: "Complete bridal makeover package",
//       popular: true,
//     },
//   ];

//  const massageServices: Service[] = [
//   { id: 101, name: "Thai Massage", category: "Massage", description: "Traditional Thai massage", image: m1, popular: true, options: [{ duration: "45 min", price: "₹1250" }, { duration: "60 min", price: "₹1625" }, { duration: "90 min", price: "₹2250" }] },
//   { id: 102, name: "Sublime Swedish Therapy", category: "Massage", description: "Gentle Swedish massage", image: m2, options: [{ duration: "45 min", price: "₹1425" }, { duration: "60 min", price: "₹1800" }, { duration: "90 min", price: "₹2300" }] },
//   { id: 103, name: "Hot Stone Therapy", category: "Massage", description: "Therapeutic massage with heated stones", image: m3, popular: true, options: [{ duration: "45 min", price: "₹1675" }, { duration: "60 min", price: "₹2300" }, { duration: "90 min", price: "₹3550" }] },
//   { id: 104, name: "Abhyanga Therapy", category: "Massage", description: "Traditional Indian oil massage", image: m4, options: [{ duration: "45 min", price: "₹1675" }, { duration: "60 min", price: "₹2300" }, { duration: "90 min", price: "₹3550" }] },
//   { id: 105, name: "Wellness Retreat Therapy", category: "Massage", description: "Extended wellness therapy", image: m5, options: [{ duration: "90 min", price: "₹2350" }] },
//   { id: 106, name: "Balinese Therapy", category: "Massage", description: "Exotic Balinese massage", image: m6, options: [{ duration: "45 min", price: "₹1675" }, { duration: "60 min", price: "₹2300" }, { duration: "90 min", price: "₹3550" }] },
//   { id: 107, name: "Sleep Therapy", category: "Massage", description: "Relaxing therapy for better sleep", image: m7, options: [{ duration: "45 min", price: "₹1238" }, { duration: "60 min", price: "₹1875" }, { duration: "90 min", price: "₹2625" }] },
//   { id: 108, name: "Deep Tissue Healing Therapy", category: "Massage", description: "Deep tissue massage", image: m8, options: [{ duration: "45 min", price: "₹1300" }, { duration: "60 min", price: "₹2050" }, { duration: "90 min", price: "₹2425" }] },
//   { id: 109, name: "Sports & Post Workout Therapy", category: "Massage", description: "Massage for muscle recovery", image: m9, options: [{ duration: "60 min", price: "₹2425" }, { duration: "90 min", price: "₹3550" }] },
//   { id: 110, name: "Healing Potli Therapy", category: "Massage", description: "Herbal potli therapy", image: m10, options: [{ duration: "60 min", price: "₹2675" }, { duration: "90 min", price: "₹4175" }] },
//   { id: 111, name: "Head & Neck Massage", category: "Massage", description: "Focused head & neck massage", image: m11, options: [{ duration: "20 min", price: "₹550" }] },
//   { id: 112, name: "Foot Reflexology", category: "Massage", description: "Foot reflexology therapy", image: m12, options: [{ duration: "30 min", price: "₹800" }] },
// ];

//   const filteredServices =
//     selectedCategory === "All"
//       ? [...existingServices, ...massageServices]
//       : selectedCategory === "Massage"
//       ? massageServices
//       : existingServices.filter((s) => s.category === selectedCategory);

//   const handleBookNow = (service: Service) => {
//     setSelectedService(service);
//     setShowPopup(true);
//   };

//   return (
//     <section id="services" className="py-20 bg-gradient-to-br from-background to-spa-cream">
//       <div className="container mx-auto px-4">
//         <div className="text-center mb-16">
//           <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
//             Our Premium Services
//           </h2>
//           <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
//             Discover our wide range of professional treatments designed to pamper and rejuvenate
//           </p>
//         </div>

//         <div className="flex flex-wrap justify-center gap-3 mb-12">
//           {categories.map((category) => {
//             const Icon = category.icon;
//             return (
//               <Button
//                 key={category.name}
//                 variant={selectedCategory === category.name ? "default" : "outline"}
//                 onClick={() => setSelectedCategory(category.name)}
//                 className="flex items-center gap-2 transition-all duration-300 hover:scale-105"
//                 disabled={category.name === "Massage" ? false : true}
//               >
//                 <Icon className="w-4 h-4" />
//                 {category.name}
//               </Button>
//             );
//           })}
//         </div>

//         {/* Services Grid */}
//         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
//           {filteredServices.map((service) => (
//             <Card key={service.id} className="group hover:shadow-strong transition-all duration-500 hover:-translate-y-2 bg-gradient-card border-0 overflow-hidden">
//               <div className="relative overflow-hidden">
//                 <img src={service.image} alt={service.name} className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-110" />

//                 {/* 🟡 Discount Tag */}
//                 <Badge className="absolute top-3 left-3 bg-yellow-400 text-yellow-900 font-semibold shadow-md text-sm px-3 py-1 rounded-md">
//                   {DISCOUNT_PERCENT}% OFF
//                 </Badge>

//                 {/* 🟢 Popular Tag */}
//                 {service.popular && (
//                   <Badge className="absolute top-3 right-3 bg-gradient-accent text-foreground">
//                     Popular
//                   </Badge>
//                 )}
//               </div>

//               <CardContent className="p-6">
//                 <h3 className="text-xl font-semibold text-foreground group-hover:text-primary transition-colors mb-3">
//                   {service.name}
//                 </h3>

//                 <div className="mb-4 text-sm text-muted-foreground">
//                   {service.options && service.options.length > 0 ? (
//                     service.options.map((opt, i) => {
//                       const discounted = getDiscountedPrice(opt.price);
//                       return (
//                         <div key={i} className="flex justify-between">
//                           <span>{opt.duration}</span>
//                           <span>
//                             <span className="line-through text-gray-400 mr-1">
//                               {opt.price}
//                             </span>
//                             <span className="font-semibold text-green-600">
//                               ₹{discounted}
//                             </span>
//                           </span>
//                         </div>
//                       );
//                     })
//                   ) : (
//                     <div className="flex justify-between">
//                       <span>{service.duration}</span>
//                       <span>
//                         <span className="line-through text-gray-400 mr-1">
//                           {service.price}
//                         </span>
//                         <span className="font-semibold text-green-600">
//                           ₹{getDiscountedPrice(service.price || "0")}
//                         </span>
//                       </span>
//                     </div>
//                   )}
//                 </div>

//                 <Button
//                   onClick={() => handleBookNow(service)}
//                   size="sm"
//                   className="bg-amber-600 hover:opacity-90 transition-all duration-300 hover:scale-105 w-full"
//                 >
//                   Book Now
//                 </Button>
//               </CardContent>
//             </Card>
//           ))}
//         </div>

//         {showPopup && selectedService && (
//           <BookingPopup
//             services={[...massageServices]}
//             selectedService={selectedService}
//             onClose={() => setShowPopup(false)}
//           />
//         )}
//       </div>
//     </section>
//   );
// };

// export default ServicesSection;



// 15/10/2025



// import { useState } from "react";
// import { motion } from "framer-motion";
// import { Card, CardContent } from "@/components/ui/card";
// import { Button } from "@/components/ui/button";
// import { Badge } from "@/components/ui/badge";
// import { Scissors, Sparkles, Palette, Crown, Heart, Hand } from "lucide-react";
// import BookingPopup, { Service } from "./BookingPopup";

// import m1 from "../assets/thai.jpg";
// import m2 from "../assets/sublime.jpg";
// import m3 from "../assets/Hot-Stone.jpg";
// import m4 from "../assets/abhiyanga.jpg";
// import m5 from "../assets/welness.jpg";
// import m6 from "../assets/balinese.jpg";
// import m7 from "../assets/sleep.jpg";
// import m8 from "../assets/deep.jpg";
// import m9 from "../assets/sport.jpg";
// import m10 from "../assets/potli.jpg";
// import m11 from "../assets/head.jpg";
// import m12 from "../assets/foot.jpg";

// const DEFAULT_DISCOUNT = 20;

// const getDiscountedPrice = (price: string, discount: number = DEFAULT_DISCOUNT) => {
//   const numeric = parseInt(price.replace(/[^\d]/g, ""), 10);
//   const discounted = numeric - (numeric * discount) / 100;
//   return discounted.toFixed(0);
// };

// const fadeUp = {
//   hidden: { opacity: 0, y: 40 },
//   visible: { opacity: 1, y: 0 },
// };

// const scaleUp = {
//   hidden: { opacity: 0, scale: 0.9, y: 40 },
//   visible: { opacity: 1, scale: 1, y: 0 },
// };

// const ServicesSection: React.FC = () => {
//   const [selectedService, setSelectedService] = useState<Service | null>(null);
//   const [showPopup, setShowPopup] = useState(false);

//   // Only Massage category
//   const categories = [
//     { name: "All", icon: Crown },
//     { name: "Hair", icon: Scissors },
//     { name: "Skin", icon: Sparkles },
//     { name: "Massage", icon: Hand },
//     { name: "Beauty", icon: Palette },
//     { name: "Special", icon: Heart },
//   ];

//   const massageServices: Service[] = [
//     { id: 101, name: "Thai Massage", category: "Massage", description: "Traditional Thai massage", image: m1, popular: true, discount: 20, options: [{ duration: "45 min", price: "₹1250" }, { duration: "60 min", price: "₹1625" }, { duration: "90 min", price: "₹2250" }] },
//     { id: 102, name: "Sublime Swedish Therapy", category: "Massage", description: "Gentle Swedish massage", image: m2, discount: 22, options: [{ duration: "45 min", price: "₹1425" }, { duration: "60 min", price: "₹1800" }, { duration: "90 min", price: "₹2300" }] },
//     { id: 103, name: "Hot Stone Therapy", category: "Massage", description: "Therapeutic massage with heated stones", image: m3, popular: true, discount: 22, options: [{ duration: "45 min", price: "₹1675" }, { duration: "60 min", price: "₹2320" }, { duration: "90 min", price: "₹3600" }] },
//     { id: 104, name: "Abhyanga Therapy", category: "Massage", description: "Traditional Indian oil massage", image: m4, discount: 22, options: [{ duration: "45 min", price: "₹1675" }, { duration: "60 min", price: "₹2320" }, { duration: "90 min", price: "₹3600" }] },
//     { id: 105, name: "Wellness Retreat Therapy", category: "Massage", description: "Extended wellness therapy", image: m5, discount: 23, options: [{ duration: "90 min", price: "₹2350" }] },
//     { id: 106, name: "Balinese Therapy", category: "Massage", description: "Exotic Balinese massage", image: m6, discount: 22, options: [{ duration: "45 min", price: "₹1675" }, { duration: "60 min", price: "₹2320" }, { duration: "90 min", price: "₹3600" }] },
//     { id: 107, name: "Sleep Therapy", category: "Massage", description: "Relaxing therapy for better sleep", image: m7, discount: 11, options: [{ duration: "45 min", price: "₹1238" }, { duration: "60 min", price: "₹1700" }, { duration: "90 min", price: "₹2140 " }] },
//     { id: 108, name: "Deep Tissue Healing Therapy", category: "Massage", description: "Deep tissue massage", image: m8, discount: 23, options: [{ duration: "45 min", price: "₹1300" }, { duration: "60 min", price: "₹2100" }, { duration: "90 min", price: "₹2475" }] },
//     { id: 109, name: "Sports & Post Workout Therapy", category: "Massage", description: "Massage for muscle recovery", image: m9, discount: 21, options: [{ duration: "60 min", price: "₹2425" }, { duration: "90 min", price: "₹3550" }] },
//     { id: 110, name: "Healing Potli Therapy", category: "Massage", popular: true, description: "Herbal potli therapy", image: m10, discount: 27, options: [{ duration: "60 min", price: "₹3175" }, { duration: "90 min", price: "₹4400" }] },
//     { id: 111, name: "Head & Neck Massage", category: "Massage", description: "Focused head & neck massage", image: m11, discount: 26, options: [{ duration: "20 min", price: "₹550" }] },
//     { id: 112, name: "Foot Reflexology", category: "Massage", description: "Foot reflexology therapy", image: m12, discount: 25, options: [{ duration: "30 min", price: "₹800" }] },
//   ];

//   const handleBookNow = (service: Service) => {
//     setSelectedService(service);
//     setShowPopup(true);
//   };

//   return (
//     <section id="services" className="py-20 bg-gradient-to-br from-background to-spa-cream">
      
//       {/* Heading */}
//       <motion.div
//         className="text-center mb-16"
//         initial="hidden"
//         animate="visible"
//         variants={fadeUp}
//         transition={{ duration: 0.5 }}
//       >
//         <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
//           Massage Services
//         </h2>
//         <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
//           Explore our professional massage treatments designed to relax and rejuvenate
//         </p>
//       </motion.div>

//       {/* Category Buttons */}
//       <motion.div
//         className="flex flex-wrap justify-center gap-3 mb-12"
//         initial="hidden"
//         animate="visible"
//         variants={fadeUp}
//         transition={{ duration: 0.5 }}
//       >
//         {categories.map((category) => {
//           const Icon = category.icon;
//           const isMassage = category.name === "Massage";
//           return (
//             <Button
//               key={category.name}
//               disabled={!isMassage}
//               variant={isMassage ? "default" : "outline"}
//               className="flex items-center gap-2 transition-all duration-300 cursor-not-allowed"
//             >
//               <Icon className="w-4 h-4" />
//               {category.name}
//             </Button>
//           );
//         })}
//       </motion.div>

//       {/* Massage Services Grid */}
//       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 container mx-auto px-4">
//         {massageServices.map((service, index) => (
//           <motion.div
//             key={service.id}
//             variants={scaleUp}
//             initial="hidden"
//             whileInView="visible"
//             viewport={{ once: false }}
//             transition={{ delay: index * 0.1, duration: 0.6 }}
//           >
//             <Card className="group hover:shadow-strong transition-all duration-500 hover:-translate-y-2 bg-gradient-card border-0 overflow-hidden">
//               <div className="relative overflow-hidden">
//                 <img
//                   src={service.image}
//                   alt={service.name}
//                   className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-110"
//                 />
//                 {service.discount && (
//                   <Badge className="absolute top-3 left-3 bg-yellow-400 text-yellow-900 font-semibold shadow-md text-sm px-3 py-1 rounded-md">
//                     {service.discount}% OFF
//                   </Badge>
//                 )}
//                 {service.popular && (
//                   <Badge className="absolute top-3 right-3 bg-gradient-accent text-foreground">
//                     Popular
//                   </Badge>
//                 )}
//               </div>

//               <CardContent className="p-6">
//                 <h3 className="text-xl font-semibold text-foreground group-hover:text-primary transition-colors mb-3">
//                   {service.name}
//                 </h3>

//                 <div className="mb-4 text-sm text-muted-foreground">
//                   {service.options && service.options.length > 0
//                     ? service.options.map((opt, i) => {
//                         const discounted = getDiscountedPrice(opt.price, service.discount);
//                         return (
//                           <div key={i} className="flex justify-between">
//                             <span>{opt.duration}</span>
//                             <span>
//                               <span className="line-through text-gray-400 mr-1">{opt.price}</span>
//                               <span className="font-semibold text-green-600">₹{discounted}</span>
//                             </span>
//                           </div>
//                         );
//                       })
//                     : (
//                       <div className="flex justify-between">
//                         <span>{service.duration}</span>
//                         <span>
//                           <span className="line-through text-gray-400 mr-1">{service.price}</span>
//                           <span className="font-semibold text-green-600">
//                             ₹{getDiscountedPrice(service.price || "0", service.discount)}
//                           </span>
//                         </span>
//                       </div>
//                     )}
//                 </div>

//                 <Button
//                   onClick={() => handleBookNow(service)}
//                   size="sm"
//                   className="bg-amber-600 hover:opacity-90 transition-all duration-300 hover:scale-105 w-full"
//                 >
//                   Book Now
//                 </Button>
//               </CardContent>
//             </Card>
//           </motion.div>
//         ))}
//       </div>

//       {showPopup && selectedService && (
//         <BookingPopup
//           services={[...massageServices]}
//           selectedService={selectedService}
//           onClose={() => setShowPopup(false)}
//         />
//       )}
//     </section>
//   );
// };

// export default ServicesSection;


import { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Scissors,
  Sparkles,
  Palette,
  Crown,
  Heart,
  Hand,
  Star,
} from "lucide-react";
import BookingPopup, { Service } from "./BookingPopup";

import m1 from "../assets/thai.jpg";
import m2 from "../assets/sublime.jpg";
import m3 from "../assets/Hot-Stone.jpg";
import m4 from "../assets/abhiyanga.jpg";
import m5 from "../assets/welness.jpg";
import m6 from "../assets/balinese.jpg";
import m7 from "../assets/sleep.jpg";
import m8 from "../assets/deep.jpg";
import m9 from "../assets/sport.jpg";
import m10 from "../assets/potli.jpg";
import m11 from "../assets/head.jpg";
import m12 from "../assets/foot.jpg";

const scaleUp = {
  hidden: { opacity: 0, scale: 0.9, y: 40 },
  visible: { opacity: 1, scale: 1, y: 0 },
};


const DEFAULT_DISCOUNT = 20;

const getDiscountedPrice = (price: string, discount: number = DEFAULT_DISCOUNT) => {
  const numeric = parseInt(price.replace(/[^\d]/g, ""), 10);
  const discounted = numeric - (numeric * discount) / 100;
  return discounted.toFixed(0);
};

const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0 },
};

const ServicesSection: React.FC = () => {
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [showPopup, setShowPopup] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("All");

  const categories = [
    { name: "All", icon: Crown },
    { name: "Hair", icon: Scissors },
    { name: "Skin", icon: Sparkles },
    { name: "Massage", icon: Hand },
    { name: "Beauty", icon: Palette },
    { name: "Special", icon: Heart },
  ];

  const massageServices: Service[] = [
    { id: 101, name: "Thai Massage", category: "Massage", description: "Traditional Thai massage", image: m1, popular: true, discount: 20, options: [{ duration: "45 min", price: "₹1250" }, { duration: "60 min", price: "₹1625" }, { duration: "90 min", price: "₹2250" }] },
    { id: 102, name: "Sublime Swedish Therapy", category: "Massage", description: "Gentle Swedish massage", image: m2, discount: 22, options: [{ duration: "45 min", price: "₹1425" }, { duration: "60 min", price: "₹1800" }, { duration: "90 min", price: "₹2300" }] },
    { id: 103, name: "Hot Stone Therapy", category: "Massage", description: "Therapeutic massage with heated stones", image: m3, popular: true, discount: 22, options: [{ duration: "45 min", price: "₹1675" }, { duration: "60 min", price: "₹2320" }, { duration: "90 min", price: "₹3600" }] },
    { id: 104, name: "Abhyanga Therapy", category: "Massage", description: "Traditional Indian oil massage", image: m4, discount: 22, options: [{ duration: "45 min", price: "₹1675" }, { duration: "60 min", price: "₹2320" }, { duration: "90 min", price: "₹3600" }] },
    { id: 105, name: "Wellness Retreat Therapy", category: "Massage", description: "Extended wellness therapy", image: m5, discount: 23, options: [{ duration: "90 min", price: "₹2350" }] },
    { id: 106, name: "Balinese Therapy", category: "Massage", description: "Exotic Balinese massage", image: m6, discount: 22, options: [{ duration: "45 min", price: "₹1675" }, { duration: "60 min", price: "₹2320" }, { duration: "90 min", price: "₹3600" }] },
    { id: 107, name: "Sleep Therapy", category: "Massage", description: "Relaxing therapy for better sleep", image: m7, discount: 11, options: [{ duration: "45 min", price: "₹1238" }, { duration: "60 min", price: "₹1700" }, { duration: "90 min", price: "₹2140 " }] },
    { id: 108, name: "Deep Tissue Healing Therapy", category: "Massage", description: "Deep tissue massage", image: m8, discount: 23, options: [{ duration: "45 min", price: "₹1300" }, { duration: "60 min", price: "₹2100" }, { duration: "90 min", price: "₹2475" }] },
    { id: 109, name: "Sports & Post Workout Therapy", category: "Massage", description: "Massage for muscle recovery", image: m9, discount: 21, options: [{ duration: "60 min", price: "₹2425" }, { duration: "90 min", price: "₹3550" }] },
    { id: 110, name: "Healing Potli Therapy", category: "Massage", popular: true, description: "Herbal potli therapy", image: m10, discount: 27, options: [{ duration: "60 min", price: "₹3175" }, { duration: "90 min", price: "₹4400" }] },
    { id: 111, name: "Head & Neck Massage", category: "Massage", description: "Focused head & neck massage", image: m11, discount: 26, options: [{ duration: "20 min", price: "₹550" }] },
    { id: 112, name: "Foot Reflexology", category: "Massage", description: "Foot reflexology therapy", image: m12, discount: 25, options: [{ duration: "30 min", price: "₹800" }] },
  ];

  const filteredServices =
    selectedCategory === "All"
      ? massageServices
      : massageServices.filter((s) => s.category === selectedCategory);

  const handleBookNow = (service: Service) => {
    setSelectedService(service);
    setShowPopup(true);
  };

  return (
    <section
      id="services"
      className="relative py-20 bg-gradient-to-b from-amber-50 via-orange-50 to-yellow-100 overflow-hidden"
    >
      {/* ✨ Floating sparkles background ✨ */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(25)].map((_, i) => (
          <motion.span
            key={i}
            className="absolute text-yellow-500 opacity-70 text-xl"
            initial={{
              top: Math.random() * 100 + "%",
              left: Math.random() * 100 + "%",
            }}
            animate={{
              y: [0, -10, 0],
              opacity: [0.6, 1, 0.6],
            }}
            transition={{
              duration: 2 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          >
            ✨
          </motion.span>
        ))}
      </div>

      {/* 🪔 Title */}
      <motion.h2
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center text-2xl sm:text-4xl font-bold text-amber-800 mb-8 drop-shadow-md"
      >
        🪔 Festive Spa Specials 🪔
      </motion.h2>

      {/* 🪔 Category Circle Buttons */}
      <div className="flex overflow-x-auto space-x-6 p-4 scrollbar-hide justify-center mb-12">
        {categories.map(({ name, icon: Icon }) => (
          <motion.div
            key={name}
            onClick={() => setSelectedCategory(name)}
            whileHover={{ scale: 1.1, rotate: 2 }}
            whileTap={{ scale: 0.95 }}
            className={`flex-shrink-0 flex flex-col items-center justify-center cursor-pointer transition-transform ${
              selectedCategory === name ? "drop-shadow-[0_0_10px_#f59e0b]" : ""
            }`}
          >
            <motion.div
              className={`relative w-14 h-14 sm:w-20 sm:h-20  rounded-full flex items-center justify-center border-4 shadow-lg ${
                selectedCategory === name
                  ? "bg-gradient-to-br from-amber-300 to-orange-200 border-amber-600"
                  : "bg-gradient-to-br from-white to-amber-100 border-amber-300"
              }`}
              animate={{
                boxShadow: [
                  "0 0 10px #f59e0b",
                  "0 0 25px #fbbf24",
                  "0 0 15px #f59e0b",
                ],
              }}
              transition={{
                repeat: Infinity,
                duration: 2,
                ease: "easeInOut",
              }}
            >
              {/* <Icon className="w-8 h-8 text-amber-700" /> */}
               <motion.span
                className=" text-xl sm:text-3xl md:text-5xl select-none"
                animate={{
                  scale: [1, 1.1, 1],
                  rotate: [0, -2, 2, 0],
                  opacity: [0.9, 1, 0.95],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              >
                🪔
              </motion.span>
            </motion.div>
            <p className="text-sm mt-3 font-semibold text-gray-800">{name}</p>
          </motion.div>
        ))}
      </div>

      {/* 🌸 Services Grid */}
      {/* <motion.div
        className="flex flex-wrap justify-center gap-3 mb-8 sm:mb-12 px-4"
        initial="hidden"
        animate="visible"
        variants={fadeUp}
        transition={{ duration: 0.5 }}
      >
        {categories.map((category) => {
          const Icon = category.icon;
          const isMassage = category.name === "Massage";
          return (
            <Button
              key={category.name}
              disabled={!isMassage}
              variant={isMassage ? "default" : "outline"}
              className="flex items-center gap-2 transition-all duration-300 cursor-not-allowed text-xs sm:text-sm md:text-base bg-gradient-to-r from-amber-400 to-orange-300 hover:scale-105 text-white shadow-md"
            >
              <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
              {category.name}
            </Button>
          );
        })}
      </motion.div> */}

      {/* Services Grid (Untouched but enhanced with glow hover) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 container mx-auto px-4 relative z-10">
        {massageServices.map((service, index) => (
          <motion.div
            key={service.id}
            variants={scaleUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: false }}
            transition={{ delay: index * 0.05, duration: 0.5 }}
          >
            <Card className="group hover:shadow-[0_0_20px_#f59e0b88] transition-all duration-500 hover:-translate-y-1 bg-gradient-to-br from-white to-amber-50 border border-amber-200 overflow-hidden flex flex-col h-full rounded-2xl">
              {/* Image Section */}
              <div className="relative overflow-hidden">
                <img
                  src={service.image}
                  alt={service.name}
                  className="w-full h-40 sm:h-44 md:h-48 object-cover transition-transform duration-500 group-hover:scale-105"
                />
                {service.discount && (
                  <Badge className="absolute top-2 left-2 bg-yellow-400 text-yellow-900 font-semibold shadow-md text-xs sm:text-sm px-2 py-1 rounded-md">
                    {service.discount}% OFF
                  </Badge>
                )}
                {service.popular && (
                  <Badge className="absolute top-2 right-2 bg-gradient-to-r from-orange-400 to-amber-500 text-white text-xs sm:text-sm px-2 py-1 rounded">
                    Popular
                  </Badge>
                )}
              </div>

              {/* Card Content */}
              <CardContent className="p-3 sm:p-4 md:p-6 flex flex-col flex-1">
                <h3 className="text-sm sm:text-base md:text-lg font-semibold text-foreground group-hover:text-amber-700 transition-colors mb-1 sm:mb-2">
                  {service.name}
                </h3>

                <p className="text-xs sm:text-sm md:text-base text-foreground mb-2 sm:mb-3 flex-1">
                  {service.description}
                </p>

                <div className="mb-2 sm:mb-3 text-xs sm:text-sm md:text-base text-foreground flex-1">
                  {service.options.map((opt, i) => {
                    const discounted = getDiscountedPrice(opt.price, service.discount);
                    return (
                      <div key={i} className="flex justify-between mb-1">
                        <span>{opt.duration}</span>
                        <span>
                          <span className="line-through text-gray-400 mr-1">{opt.price}</span>
                          <span className="font-semibold text-green-600">₹{discounted}</span>
                        </span>
                      </div>
                    );
                  })}
                </div>

                {/* Action Buttons */}
                <div className="mt-2 flex w-full gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1 min-w-0 text-xs sm:text-sm md:text-base bg-white dark:bg-gray-800 text-foreground hover:bg-gray-100 dark:hover:bg-gray-700 transition-all duration-300"
                  >
                    Add to Cart
                  </Button>

                  <Button
                    onClick={() => handleBookNow(service)}
                    size="sm"
                    className="flex-1 min-w-0 text-xs sm:text-sm md:text-base bg-gradient-to-r from-amber-500 to-orange-500 hover:opacity-90 transition-all duration-300 hover:scale-105 text-white shadow-md"
                  >
                    Book Now
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {showPopup && selectedService && (
        <BookingPopup
          service={selectedService}
          onClose={() => setShowPopup(false)}
        />
      )}
    </section>
  );
};

export default ServicesSection;
