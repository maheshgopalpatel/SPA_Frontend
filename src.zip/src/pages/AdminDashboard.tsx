import { useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, Calendar, DollarSign } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import SettingsMenu from "@/components/SettingsMenu";

const formatDate = (isoDate: string) => {
  if (!isoDate) return "";
  const d = new Date(isoDate);
  return d.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
};

const formatTime = (isoTime: string) => {
  if (!isoTime) return "";
  const d = new Date(isoTime);
  const hours = d.getUTCHours();
  const minutes = d.getUTCMinutes();
  const ampm = hours >= 12 ? "PM" : "AM";
  const hour12 = hours % 12 || 12;
  return `${hour12}:${minutes.toString().padStart(2, "0")} ${ampm}`;
};

const AdminDashboard = () => {
  const [stats, setStats] = useState({
    totalBookings: 0,
    monthlyRevenue: 0,
    activeStaff: 8,
    totalCustomers: 0,
  });

  const [recentBookings, setRecentBookings] = useState<any[]>([]);
  const [contactInfo, setContactInfo] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const { logout } = useAuth();

  const BOOKINGS_SHEET_URL = import.meta.env.VITE_GOOGLE_SHEET_URL

  const CONTACT_SHEET_URL = import.meta.env.VITE_GET_MESSAGE_URL

  // 🟩 Fetch bookings
  useEffect(() => {
    const fetchBookings = async () => {
      setLoading(true);
      try {
        const res = await fetch(BOOKINGS_SHEET_URL);
        const data = await res.json();

        if (data.status === "success") {
          const bookings = data.bookings.reverse();
          const totalRevenue = bookings.reduce(
            (sum, b) => sum + (parseFloat(b.totalAmount) || 0),
            0
          );

          setRecentBookings(bookings);
          setStats({
            totalBookings: bookings.length,
            monthlyRevenue: totalRevenue,
            activeStaff: 8,
            totalCustomers: new Set(bookings.map((b) => b.phone)).size,
          });
        }
      } catch (err) {
        console.error("Bookings fetch failed:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchBookings();
  }, []);

  // 🟦 Fetch contact info
  useEffect(() => {
    const fetchContacts = async () => {
      try {
        const res = await fetch(CONTACT_SHEET_URL);
        const data = await res.json();
        if (data.status === "success") setContactInfo(data.data);
      } catch (err) {
        console.error("Contacts fetch failed:", err);
      }
    };

    fetchContacts();
  }, []);

  console.log(contactInfo);

  return (
    <div className="min-h-screen bg-background p-6 text-foreground">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">Admin Dashboard</h1>
            <p className="text-muted-foreground">
              Manage your spa operations effectively
            </p>
          </div>
          <SettingsMenu />
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="h-full bg-card text-card-foreground shadow-sm border border-border">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">
                Total Bookings
              </CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalBookings}</div>
            </CardContent>
          </Card>

          <Card className="h-full bg-card text-card-foreground shadow-sm border border-border">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">
                Monthly Revenue
              </CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                ₹{stats.monthlyRevenue.toLocaleString()}
              </div>
            </CardContent>
          </Card>

          <Card className="h-full bg-card text-card-foreground shadow-sm border border-border">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Active Staff</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.activeStaff}</div>
              <p className="text-xs text-muted-foreground">2 new this month</p>
            </CardContent>
          </Card>

          <Card className="h-full bg-card text-card-foreground shadow-sm border border-border">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">
                Total Customers
              </CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalCustomers}</div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs Section */}
        <Tabs defaultValue="bookings" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="bookings">Bookings</TabsTrigger>
            <TabsTrigger value="contactInfo">Contact Info</TabsTrigger>
            <TabsTrigger disabled>Services</TabsTrigger>
            <TabsTrigger disabled>Gallery</TabsTrigger>
            <TabsTrigger disabled>Analytics</TabsTrigger>
          </TabsList>

          {/* BOOKINGS TAB */}
          <TabsContent value="bookings">
            <Card className="bg-card text-card-foreground border border-border shadow-sm">
              <CardHeader>
                <CardTitle>Recent Bookings</CardTitle>
                <CardDescription>
                  Track and manage appointments
                </CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <p className="text-center text-muted-foreground">
                    Loading...
                  </p>
                ) : recentBookings.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="min-w-full border border-border rounded-lg overflow-hidden">
                      <thead className="bg-muted/30 text-muted-foreground">
                        <tr>
                          <th className="px-4 py-3 text-left text-sm font-semibold">
                            Name
                          </th>
                          <th className="px-4 py-3 text-left text-sm font-semibold">
                            Service
                          </th>
                          <th className="px-4 py-3 text-left text-sm font-semibold">
                            Date
                          </th>
                          <th className="px-4 py-3 text-left text-sm font-semibold">
                            Time
                          </th>
                          <th className="px-4 py-3 text-left text-sm font-semibold">
                            Phone
                          </th>
                          <th className="px-4 py-3 text-right text-sm font-semibold">
                            Amount
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {recentBookings.slice(0, 10).map((booking, i) => (
                          <tr
                            key={i}
                            className="border-t border-border hover:bg-muted/10 transition"
                          >
                            <td className="px-4 py-3">{booking.name}</td>
                            <td className="px-4 py-3 capitalize text-primary font-medium">
                              {booking.services}
                            </td>
                            <td className="px-4 py-3">
                              {formatDate(booking.date)}
                            </td>
                            <td className="px-4 py-3">
                              {formatTime(booking.time)}
                            </td>
                            <td className="px-4 py-3">{booking.phone}</td>
                            <td className="px-4 py-3 text-right">
                              <Badge variant="outline">
                                ₹{booking.totalAmount}
                              </Badge>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground">
                    No bookings found
                  </p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* CONTACT INFO TAB */}
          <TabsContent value="contactInfo">
            <Card className="bg-card text-card-foreground border border-border shadow-sm">
              <CardHeader>
                <CardTitle>Recent Messages</CardTitle>
                <CardDescription>
                  Messages received from contact form
                </CardDescription>
              </CardHeader>
              <CardContent>
                {contactInfo.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="min-w-full border border-border rounded-lg overflow-hidden">
                      <thead className="bg-muted/30 text-muted-foreground">
                        <tr>
                          <th className="px-4 py-3 text-left text-sm font-semibold">Name</th>
                          <th className="px-4 py-3 text-left text-sm font-semibold">Mobile</th>
                          <th className="px-4 py-3 text-left text-sm font-semibold">Email</th>
                          <th className="px-4 py-3 text-left text-sm font-semibold">Message</th>
                          <th className="px-4 py-3 text-left text-sm font-semibold">Time</th>
                        </tr>
                      </thead>
                      <tbody>
                        {contactInfo.slice(0, 10).map((msg, i) => (
                          <tr key={i} className="border-t border-border hover:bg-muted/10 transition">
                            <td className="px-4 py-3">{msg.name}</td>
                            <td className="px-4 py-3">{msg.phone}</td>
                            <td className="px-4 py-3">{msg.email}</td>
                            <td className="px-4 py-3">{msg.message}</td>
                            <td className="px-4 py-3">{msg.timestamp}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground">
                    No messages found
                  </p>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboard;
