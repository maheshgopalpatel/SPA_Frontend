import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Calendar,
  Clock,
  Star,
  Gift,
  MapPin,
  Phone,
  User,
  CreditCard,
  Plus,
  Edit,
  Heart,
} from "lucide-react";
import SettingsMenu from "@/components/SettingsMenu";

const CustomerDashboard = () => {
  const [customerStats] = useState({
    totalVisits: 23,
    loyaltyPoints: 1450,
    nextReward: 2000,
    memberSince: "Jan 2023",
  });

  const [upcomingBookings] = useState([
    {
      id: 1,
      service: "Deep Tissue Massage",
      staff: "Priya Sharma",
      date: "2024-01-15",
      time: "2:00 PM",
      status: "confirmed",
      location: "Room 3",
    },
    {
      id: 2,
      service: "Hair Color & Cut",
      staff: "Rahul Kumar",
      date: "2024-01-20",
      time: "11:00 AM",
      status: "pending",
      location: "Hair Studio",
    },
  ]);

  const [serviceHistory] = useState([
    {
      id: 1,
      service: "Facial Treatment",
      staff: "Anita Patel",
      date: "2024-01-05",
      amount: 1200,
      rating: 5,
      reviewed: true,
    },
    {
      id: 2,
      service: "Manicure & Pedicure",
      staff: "Sita Rani",
      date: "2023-12-28",
      amount: 800,
      rating: 4,
      reviewed: true,
    },
    {
      id: 3,
      service: "Hair Styling",
      staff: "Rahul Kumar",
      date: "2023-12-15",
      amount: 1000,
      rating: 0,
      reviewed: false,
    },
  ]);

  const [favoriteServices] = useState([
    { name: "Deep Tissue Massage", bookings: 8 },
    { name: "Facial Treatment", bookings: 5 },
    { name: "Hair Styling", bookings: 4 },
  ]);

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="w-full flex gap-3 mb-8 items-center">
          <div className="w-full flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">
                My Dashboard
              </h1>
              <p className="text-muted-foreground">
                Welcome back! Manage your appointments and profile
              </p>
            </div>
            <Button className="bg-amber-600">
              <Plus className="w-4 h-4 mr-2" />
              Book Appointment
            </Button>
          </div>
          <SettingsMenu />
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Visits
              </CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {customerStats.totalVisits}
              </div>
              <p className="text-xs text-muted-foreground">
                Member since {customerStats.memberSince}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Loyalty Points
              </CardTitle>
              <Gift className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {customerStats.loyaltyPoints}
              </div>
              <p className="text-xs text-muted-foreground">
                {customerStats.nextReward - customerStats.loyaltyPoints} points
                to next reward
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Upcoming Visits
              </CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {upcomingBookings.length}
              </div>
              <p className="text-xs text-muted-foreground">
                Next: {upcomingBookings[0]?.date}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Favorite Service
              </CardTitle>
              <Heart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-lg font-bold">
                {favoriteServices[0]?.name}
              </div>
              <p className="text-xs text-muted-foreground">
                {favoriteServices[0]?.bookings} times booked
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="bookings" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="bookings">My Bookings</TabsTrigger>
            <TabsTrigger value="history">Service History</TabsTrigger>
            <TabsTrigger value="loyalty">Loyalty & Rewards</TabsTrigger>
            <TabsTrigger value="profile">My Profile</TabsTrigger>
          </TabsList>

          <TabsContent value="bookings" className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Upcoming Appointments</CardTitle>
                  <CardDescription>Your scheduled services</CardDescription>
                </div>
                <Button className="bg-amber-600">
                  <Plus className="w-4 h-4 mr-2" />
                  New Booking
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {upcomingBookings.map((booking) => (
                    <div
                      key={booking.id}
                      className="p-4 border rounded-lg space-y-3"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium text-lg">
                            {booking.service}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            with {booking.staff}
                          </p>
                        </div>
                        <Badge
                          variant={
                            booking.status === "confirmed"
                              ? "default"
                              : "secondary"
                          }
                        >
                          {booking.status}
                        </Badge>
                      </div>

                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="flex items-center space-x-2">
                          <Calendar className="w-4 h-4 text-muted-foreground" />
                          <span>{booking.date}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Clock className="w-4 h-4 text-muted-foreground" />
                          <span>{booking.time}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <MapPin className="w-4 h-4 text-muted-foreground" />
                          <span>{booking.location}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Phone className="w-4 h-4 text-muted-foreground" />
                          <span>+91 62077 42437</span>
                        </div>
                      </div>

                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          <Edit className="w-4 h-4 mr-2" />
                          Reschedule
                        </Button>
                        <Button variant="outline" size="sm">
                          Cancel
                        </Button>
                        <Button variant="outline" size="sm">
                          View Details
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Service History</CardTitle>
                <CardDescription>
                  Your past appointments and reviews
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {serviceHistory.map((service) => (
                    <div key={service.id} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <p className="font-medium">{service.service}</p>
                          <p className="text-sm text-muted-foreground">
                            with {service.staff}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">₹{service.amount}</p>
                          <p className="text-sm text-muted-foreground">
                            {service.date}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          {service.rating > 0 ? (
                            <div className="flex items-center space-x-1">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <Star
                                  key={star}
                                  className={`w-4 h-4 ${
                                    star <= service.rating
                                      ? "text-yellow-500 fill-current"
                                      : "text-gray-300"
                                  }`}
                                />
                              ))}
                            </div>
                          ) : (
                            <span className="text-sm text-muted-foreground">
                              Not rated
                            </span>
                          )}
                        </div>

                        <div className="flex space-x-2">
                          {!service.reviewed && (
                            <Button variant="outline" size="sm">
                              <Star className="w-4 h-4 mr-2" />
                              Leave Review
                            </Button>
                          )}
                          <Button variant="outline" size="sm">
                            Book Again
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="loyalty" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Loyalty Points & Rewards</CardTitle>
                <CardDescription>
                  Track your points and redeem rewards
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="text-center p-6 bg-gradient-card rounded-lg">
                    <div className="text-3xl font-bold text-primary mb-2">
                      {customerStats.loyaltyPoints}
                    </div>
                    <p className="text-muted-foreground">Available Points</p>
                    <div className="w-full bg-muted rounded-full h-2 mt-4">
                      <div
                        className="bg-amber-600 h-2 rounded-full"
                        style={{
                          width: `${
                            (customerStats.loyaltyPoints /
                              customerStats.nextReward) *
                            100
                          }%`,
                        }}
                      ></div>
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">
                      {customerStats.nextReward - customerStats.loyaltyPoints}{" "}
                      points to next reward
                    </p>
                  </div>

                  <div className="grid gap-4">
                    <h3 className="font-medium">Available Rewards</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <p className="font-medium">Free Hair Wash</p>
                          <p className="text-sm text-muted-foreground">
                            500 points
                          </p>
                        </div>
                        <Button
                          size="sm"
                          disabled={customerStats.loyaltyPoints < 500}
                        >
                          Redeem
                        </Button>
                      </div>
                      <div className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <p className="font-medium">10% Off Any Service</p>
                          <p className="text-sm text-muted-foreground">
                            1000 points
                          </p>
                        </div>
                        <Button
                          size="sm"
                          disabled={customerStats.loyaltyPoints < 1000}
                        >
                          Redeem
                        </Button>
                      </div>
                      <div className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <p className="font-medium">Free Facial Treatment</p>
                          <p className="text-sm text-muted-foreground">
                            2000 points
                          </p>
                        </div>
                        <Button
                          size="sm"
                          disabled={customerStats.loyaltyPoints < 2000}
                        >
                          Redeem
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>My Profile</CardTitle>
                <CardDescription>
                  Manage your personal information and preferences
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 text-muted-foreground">
                  <User className="w-12 h-12 mx-auto mb-4" />
                  <p className="text-lg font-medium">Customer Profile</p>
                  <p className="text-sm">
                    Profile management interface will be displayed here
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default CustomerDashboard;
